export interface ICachingService {
    saveToLocalStorage: (key: string, value: any) => void;
    getFromLocalStorage: (key: string) => string;
    updateLocalStorageValue: (key: string, value: any) => void;
    removeValueFromLocalStorage: (key: string) => void;
    saveToSessionStorage: (key: string, value: any) => void;
    getFromSessionStorage: (key: string) => string;
    updateSessionStorageValue: (key: string, value: any) => void;
    removeValueFromSessionStorage: (key: string) => void;
  }
