import { SpUser } from "../types/SpUser";

export default interface IUserDataService {
  getFirstName: () => Promise<string>;

  getLastName: () => Promise<string>;

  getFullName: () => Promise<string>;

  getUserObject: () => Promise<SpUser>;

  getUserAtoZLinks: () => Promise<any>;

  getUserAapplications: () => Promise<any>;

  getIsSiteAdmin: () => Promise<boolean>;

  getNwieID: () => Promise<string>;

  getUserProfile: (loginName?: string) => Promise<any>;
}

/*
https://rtc.nwie.net/jazz/web/projects/Dev%20Center#action=com.ibm.team.workitem.viewWorkItem&id=1292358
https://sharepoint.stackexchange.com/questions/222091/spfx-how-to-get-current-user-properties-with-pnp-js-core

*/
