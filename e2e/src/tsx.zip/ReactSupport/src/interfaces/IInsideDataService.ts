import { WeatherData } from "../types/WeatherTypes/WeatherData";
import { InsideUserData } from "../types/InsideUserData";
import { InsideAdmin } from "../types/AdminTypes/InsideAdmin";
import { InsideEvent } from "../types/EventTypes/InsideEvent";

export interface IInsideDataService {
  getWeatherData: (zipcode?: string) => Promise<WeatherData>;
  getUserPreferences: (nwieID: string) => Promise<InsideUserData>;
  saveDataToInside: (insideUserData: InsideUserData) => Promise<Response>;
  getUserAdminStatus: (nwieID: string) => Promise<InsideAdmin>;
  getEventsAndPayroll: (nwieID: string) => Promise<InsideEvent>;
  updateInsideData: (insideUserData: InsideUserData) => Promise<Response>;
}
