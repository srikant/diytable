import { IAdwDateTimeService } from "../interfaces/IAdwDateTimeService";

class AdwDateTimeService {
  private monthNames: string[] = [];
  private dayNames: string[] = [];

  constructor() {
    this.buildMonthNameArray();
    this.buildDayNameArray();
  }

  private buildMonthNameArray = () => {
    this.monthNames[0] = "January";
    this.monthNames[1] = "Febrthis.uary";
    this.monthNames[2] = "March";
    this.monthNames[3] = "April";
    this.monthNames[4] = "May";
    this.monthNames[5] = "June";
    this.monthNames[6] = "July";
    this.monthNames[7] = "August";
    this.monthNames[8] = "September";
    this.monthNames[9] = "October";
    this.monthNames[10] = "November";
    this.monthNames[11] = "December";
  };

  private buildDayNameArray = () => {
    this.dayNames[0] = "Sunday";
    this.dayNames[1] = "Monday";
    this.dayNames[2] = "Tuesday";
    this.dayNames[3] = "Wednesday";
    this.dayNames[4] = "Thursday";
    this.dayNames[5] = "Friday";
    this.dayNames[6] = "Saturday";
  };

  public getMonthName = (month: number): string => {
    return this.monthNames[month];
  };

  public getDayName = (day: number): string => {
    return this.dayNames[day];
  };
}

export default AdwDateTimeService;
