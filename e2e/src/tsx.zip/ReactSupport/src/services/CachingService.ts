import { ICachingService } from "../interfaces/ICachingService";
import IEnvironmentService from "../interfaces/IEnvironmentService";
import EnvironmentService from "./EnvironmentService";

export interface ICachingObject {
  [key: string]: string;
  environment: string;
  timestamp: string;
}

class CachingService implements ICachingService {
  private _environmentService: IEnvironmentService;
  private _environment: string;

  constructor() {
    this._environmentService = new EnvironmentService();
    this._environment = this._environmentService.getEnvironment();
  }

  public saveToLocalStorage = (key: string, value: string): void => {
    localStorage.setItem(`${key}-${this._environment}`, value);
  };

  public getFromLocalStorage = (key: string): string => {
    return localStorage.getItem(`${key}-${this._environment}`);
  };

  public updateLocalStorageValue = (key: string, value: string): void => {
    this.saveToLocalStorage(key, value);
  };

  public removeValueFromLocalStorage = (key: string): void => {
    localStorage.removeItem(`${key}-${this._environment}`);
  };

  public saveToSessionStorage = (key: string, value: string): void => {
    sessionStorage.setItem(`${key}-${this._environment}`, value);
  };

  public getFromSessionStorage = (key: string): string => {
    return sessionStorage.getItem(`${key}-${this._environment}`);
  };

  public updateSessionStorageValue = (key: string, value: string): void => {
    this.saveToSessionStorage(key, value);
  };

  public removeValueFromSessionStorage = (key: string): void => {
    sessionStorage.removeItem(`${key}-${this._environment}`);
  };
}

export default CachingService;
