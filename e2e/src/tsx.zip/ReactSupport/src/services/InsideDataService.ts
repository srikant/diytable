import { IInsideDataService } from "../interfaces/IInsideDataService";
import { WeatherData } from "../types/WeatherTypes/WeatherData";
import { InsideAdmin } from "../types/AdminTypes/InsideAdmin";
import { InsideUserData } from "../types/InsideUserData";
import IEnvironmentService from "../interfaces/IEnvironmentService";
import EnvironmentService from "./EnvironmentService";
import { ICachingService } from "../interfaces/ICachingService";
import CachingService from "./CachingService";
import { InsideEvent } from "../types/EventTypes/InsideEvent";

class InsideDataService implements IInsideDataService {
  private _cachingService: ICachingService;
  private _environmentService: IEnvironmentService;
  private insideUrl: string;

  constructor() {
    this._cachingService = new CachingService();
    this._environmentService = new EnvironmentService();
    this.insideUrl = this._environmentService.getInsideUrl();
  }

  /*
  * https://dev-inside.nwie.net/inside-web/adwUserPreferences/getEventsAndPayrollCalendar
  */
  public getEventsAndPayroll = async (nwieID: string): Promise<InsideEvent> => {
    if (nwieID) {
      nwieID = nwieID.toLowerCase();
    }

    const url: string = `${this.insideUrl}/AdwUserPreferences/getEventsAndPayrollCalendar?adwloginId=${nwieID}`;
    console.log("Url >>> ", url);
    return fetch(url).then(response => {
      return response.json();
    });
  };

  /*
  * https://dev-inside.nwie.net/inside-web/weather/getWeatherData?zip=43215
  */
  public getWeatherData = (zipcode?: string): Promise<WeatherData> => {
    if (!zipcode) {
      zipcode = "43215";
    }
    return fetch(`${this.insideUrl}/weather/getWeatherData?zip=${zipcode}`).then(response => response.json());
  };

  /*
  * Sample Web Call
  * https://dev-inside.nwie.net/inside-web/admin/getUserAdminStatus?nwieID=eric.chin
  */
  public getUserAdminStatus = (nwieID: string): Promise<InsideAdmin> => {
    if (nwieID) {
      nwieID = nwieID.toLowerCase();
    }
    const url: string = `${this.insideUrl}/admin/getUserAdminStatus?nwieID=${nwieID}`;
    return fetch(url).then(response => response.json());
  };

  public getUserPreferences = async (nwieID: string): Promise<InsideUserData> => {
    const cachedInsideData: InsideUserData = JSON.parse(this._cachingService.getFromLocalStorage("InsideUser"));

    if (cachedInsideData) {
      return Promise.resolve(cachedInsideData);
    } else {
      const url: string = `${this.insideUrl}/AdwUserPreferences/getAdwUser?userId=${nwieID}`;
      const insideUser: InsideUserData = await fetch(url).then(response => response.json());
      this._cachingService.saveToLocalStorage("InsideUser", JSON.stringify(insideUser));
      return insideUser;
    }
  };

  public saveDataToInside = (insideUserData: InsideUserData): Promise<Response> => {
    this._cachingService.updateLocalStorageValue("InsideUser", JSON.stringify(insideUserData));

    const url: string = `${this.insideUrl}/AdwUserPreferences/saveAdwUser`;
    const requestData: {} = {
      adwUser: insideUserData,
    };

    return fetch(url, {
      method: "POST",
      mode: "cors",
      body: JSON.stringify(requestData),
      cache: "no-cache",
    });
  };

  public updateInsideData = async (insideUserData: InsideUserData): Promise<Response> => {
    return await this.saveDataToInside(insideUserData);
  };
}

export default InsideDataService;
