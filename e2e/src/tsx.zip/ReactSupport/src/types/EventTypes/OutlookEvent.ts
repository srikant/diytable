import AdwEvent from "./AdwEvent";

class OutlookEvent {
  public ecDate: string;

  constructor(adwEvent: AdwEvent) {
    this.ecDate = adwEvent.ecDate;
  }
}
export default OutlookEvent;
