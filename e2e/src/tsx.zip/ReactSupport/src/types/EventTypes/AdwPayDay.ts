import { InsidePayDay } from "./InsidePayDay";
// import { InsideEventDetails } from "./InsideEventDetails";
import * as moment from "moment";

class AdwPayDay {
  public payDay: string;
  // need to check: InsidePayDay
  constructor(iPayDay: InsidePayDay) {
    console.log("iPayDay >> ", iPayDay);
    this.payDay = this.getDateFormatExpected(iPayDay.eventDate); // iPayDay.paydays.eventDate); // (iPayDay.eventDate
  }

  getDateFormatExpected(date: string): string {
    let formattedDate: string = moment(date).format("l");
    console.log("formattedDate >>", formattedDate);
    let splitDate: string[] = formattedDate.split("/"); // substring(0, 4); // "9/7";
    console.log("splitDate >>", splitDate);
    let returnDate: string = `${splitDate[0]}/${splitDate[1]}`;
    console.log("returnDate >>", returnDate);
    // to Do manipulate the string to be what we expect
    // sample value of the string "2018-09-21T04:00:00Z"
    // should look like 9/21

    return returnDate;
  }
}
export default AdwPayDay;
