import { InsideEvent } from "./InsideEvent";
import { InsideEventDetails } from "./InsideEventDetails";

class AdwEvent {
  public ecDay: string; // ecDay
  public ecDate: string; // ecDate
  public ecMonth: string; // ecMonth
  public ecTitle: string; // ecTitle
  public ecTime: string; // ecTime
  public ecUrl: string; // ecUrl
  public ecColor: string; // ecColor
  public ecStartDate: string; // ecStartDate
  public ecEndDate: string; // ecEndDate
  public ecLocation: string; // ecLocation
  public ecDescription: string; // ecDescription

  constructor(ied: InsideEventDetails) {
    this.ecDay = ied.dom; // fri
    this.ecDate = ied.dow; // 5
    this.ecMonth = ied.displayMonth;
    this.ecTitle = ied.event.title;
    this.ecTime = this.getStartAndEndTimes(ied.event.startTime, ied.event.endTime);
    this.ecUrl = this.getURL();
    this.ecColor = ied.event.eventType.eventColor;
    this.ecStartDate = this.getDateOnlyFromTimeStamp(ied.event.startTime);
    this.ecEndDate = this.getDateOnlyFromTimeStamp(ied.event.endTime);
    this.ecLocation = ied.event.eventLocation.eventLocation;
    this.ecDescription = ied.event.description;
  }

  // sample value 2018-09-21T04:00:00Z
  getStartAndEndTimes(start: string, end: string): string {
    console.log("getStartAndEndTimes : ", start);
    let time: string = "12:00 p.m. - 5:00 p.m.";
    time = `${start} - ${end}`;

    // uSe momment to return the expected format

    return time;
  }

  getDateOnlyFromTimeStamp(dateString: string): string {
    console.log("getDateOnlyFromTimeStamp : ", dateString);
    // sample dateString 2018-09-21T04:00:00Z
    let returnString: string = dateString;
    // uSe momment to return the expected format
    return returnString;
  }

  getURL(): string {
    console.log("getURL : ");
    let url: string = "https://dev-inside.nwie.net/inside-web/companyEventCalendar/openEventCalendar";
    // taking them to inside, and opening a modal?
    // we need to talk about options on how to handle this
    // there is a card in the backlog to handle this story now
    return url;
  }
}
export default AdwEvent;
