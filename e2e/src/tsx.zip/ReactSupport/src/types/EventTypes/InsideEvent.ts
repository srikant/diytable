import { InsideEventDetails } from "./InsideEventDetails";

export type InsideEvent = {
  employeeNumber: number;
  events: InsideEventDetails[];
  paydays: any[]; // toDO define this object
};
