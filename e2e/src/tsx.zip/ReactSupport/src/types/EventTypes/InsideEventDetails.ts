export type InsideEventDetails = {
    displayMonth: string;
    dom: string;
    dow: string;
    event: {
      addToCalFilename: string;
      class: string;
      description: string;
      endTime: string; // sample value 2018-09-21T04:00:00Z
      eventDate: string; // sample value 2018-09-21T04:00:00Z
      id: number;
      locations: string;
      recurringEventId: number;
      startTime: string;
      status: string;
      title: string;
      eventLocation: {
        class: string;
        displayOrder: number;
        eventLocation: string;
        id: number;
      };
      eventType: {
        class: string;
        eventColor: string;
        eventType: string;
        id: number;
      };
    };
  };
