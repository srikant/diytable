import { SpCampaignBanner } from "./SpCampaignBanner";

class AdwCampaignBanner {
  public id: number;
  public AlternativeText: string;
  public ImagePath: string[]; // set From the service, not in SP list
  public LinkPath: string;
  public WindowTarget: string;
  public DisplayOrder: number;
  public DisplayEnabled: boolean;
  public StartDate: string;
  public EndDate: string;
  constructor(spCampaignBanner?: SpCampaignBanner) {
    if (spCampaignBanner) {
      this.id = spCampaignBanner.Id;
      this.WindowTarget = spCampaignBanner.WindowTarget;
      this.ImagePath = spCampaignBanner.ImageUrl;
      this.StartDate = spCampaignBanner.StartDate;
      this.EndDate = spCampaignBanner.EndDate;
    }
  }
}

export default AdwCampaignBanner;
