class AdwEventDetails {
    public ecDay: string;
    public ecDate: string;
    public ecMonth: string;
    public ecTitle: string;
    public ecTime: string;
    public ecUrl: string;
    public ecColor: string;
    public ecStartDate: string;
    public ecEndDate: string;
    public ecLocation: string;
    public ecDescription: string;

    constructor(
      ecDay: string,
      ecDate: string,
      ecMonth: string,
      ecTitle: string,
      ecTime: string,
      ecUrl: string,
      ecColor: string,
      ecStartDate: string,
      ecEndDate: string,
      ecLocation: string,
      ecDescription: string,
    ) {
      this.ecDay = ecDay;
      this.ecDate = ecDate;
      this.ecMonth = ecMonth;
      this.ecTitle = ecTitle;
      this.ecTime = ecTime;
      this.ecUrl = ecUrl;
      this.ecColor = ecColor;
      this.ecStartDate = ecStartDate;
      this.ecEndDate = ecEndDate;
      this.ecLocation = ecLocation;
      this.ecDescription = ecDescription;
    }
  }
  export default AdwEventDetails;
