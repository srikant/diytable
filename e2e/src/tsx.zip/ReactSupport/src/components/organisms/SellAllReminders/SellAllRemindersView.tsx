import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { DesktopArrowButton } from "../../atoms";
import Reminders from "../../organisms/Reminders/Reminders";
import AdwReminder from "../../../types/ReminderTypes/AdwReminder";
import EnvironmentService from "../../../services/EnvironmentService";
import SpApiService from "../../../services/SpApiService";
import { SpReminder } from "../../../types/ReminderTypes/SpReminder";
import styles from "./SeeAllRemindersView.module.scss";

export interface ISeeAllRemindersProps {
  absoluteUrl: string;
}

export interface ISeeAllRemindersState {
  reminderArray: AdwReminder[];
}

class SeeAllReminders extends React.Component<ISeeAllRemindersProps, ISeeAllRemindersState> {
  private environmentService: EnvironmentService;
  private spApiService: SpApiService;
  constructor(props: ISeeAllRemindersProps) {
    super(props);
    this.environmentService = new EnvironmentService();
    this.spApiService = new SpApiService(this.props.absoluteUrl);
    this.state = {
      reminderArray: [] as AdwReminder[],
    };
  }

  public async componentDidMount(): Promise<void> {
    const remindersArray: AdwReminder[] = await this.getReminders();
    this.setState({
      reminderArray: remindersArray,
    });
  }

  private getReminders(): Promise<AdwReminder[]> {
    let reminderPromise: Promise<AdwReminder[]>;
    const siteUrl: string = this.environmentService.getSiteUrl();
    reminderPromise = this.spApiService.getListItems("Reminders", siteUrl).then((spReminders: SpReminder[]) => {
      const spReminderArray: SpReminder[] = spReminders;
      const adwReminderArray: AdwReminder[] = spReminderArray.map(spReminder => {
        return new AdwReminder(spReminder);
      });
      return adwReminderArray;
    });
    return reminderPromise;
  }

  handleBackClick = (): void => {
    window.history.back();
  };

  handleCloseButtonClick = (): void => {
    window.history.back();
  };
  public render(): React.ReactElement<ISeeAllRemindersProps> {
    return (
      <div className={styles.SeeAllRemindersWrapper}>
        <div className={styles.toolsHeading}>
          <div className={styles.closeButton} onClick={this.handleCloseButtonClick}>
            <div className={styles.closeX} />
            <span className={styles.closeText}>CLOSE</span>
          </div>
        </div>
        <div className={styles.RemindersArrayHeight}>
          <Reminders reminderArray={this.state.reminderArray} isDisplaySeeAllReminders={true} />
        </div>
        <div className={styles.backLinkActions}>
          <div className={styles.backLink} onClick={this.handleBackClick}>
            <DesktopArrowButton desktopArrow={styles.arrow} />
            <span>Back</span>
          </div>
        </div>
      </div>
    );
  }
}

export default SeeAllReminders;
 