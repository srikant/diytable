import * as React from "react";
import styles from "./SitesAtoZview.module.scss";
import { ISitesAtoZProps } from "../../../webparts/sitesAtoZ/components/ISitesAtoZProps";
import EnvironmentService from "../../../services/EnvironmentService";
import SpUserDataService from "../../../services/SpUserDataService";
import InsideDataService from "../../../services/InsideDataService";
import SpApiService from "../../../services/SpApiService";
import AtoZ from "../../organisms/AtoZ/AtoZ";
import Events from "../../organisms/Events/Events";
import Reminders from "../../organisms/Reminders/Reminders";
import AdwAtoZLink from "../../../types/AtoZtypes/AdwAtoZLink";
import { InsideAtoZSite } from "../../../types/AtoZtypes/InsideAtoZSite";
import AdwReminder from "../../../types/ReminderTypes/AdwReminder";
import { SpReminder } from "../../../types/ReminderTypes/SpReminder";
import { InsideEvent } from "../../../types/EventTypes/InsideEvent";
import { InsideEventDetails } from "../../../types/EventTypes/InsideEventDetails";
import { InsidePayDay } from "../../../types/EventTypes/InsidePayDay";
import AdwEvent from "../../../types/EventTypes/AdwEvent";
import AdwPayDay from "../../../types/EventTypes/AdwPayDay";

export interface IDisplayOption {
  deviceName: string;
  isDisplay: boolean;
}

export interface ISitesAtoZState {
  siteArray: AdwAtoZLink[];
  insideEventsAndPayrolls: InsideEvent;
  eventsArray: AdwEvent[];
  payDayArray: AdwPayDay[];
  reminderArray: AdwReminder[];
  isTablet: boolean;
  displayOptions: IDisplayOption[];
}

class SitesAtoZview extends React.Component<ISitesAtoZProps, ISitesAtoZState> {
  private environmentService: EnvironmentService;
  private spApiService: SpApiService;
  private spUserDataService: SpUserDataService;
  private insideDataService: InsideDataService;
  constructor(props: ISitesAtoZProps) {
    super(props);
    this.environmentService = new EnvironmentService();
    this.spApiService = new SpApiService();
    this.spUserDataService = new SpUserDataService(this.props.context);
    this.insideDataService = new InsideDataService();
    this.state = {
      siteArray: [] as AdwAtoZLink[],
      reminderArray: [] as AdwReminder[],
      insideEventsAndPayrolls: [] as any,
      eventsArray: [] as AdwEvent[],
      payDayArray: [] as AdwPayDay[],
      isTablet: false,
      displayOptions: [] as IDisplayOption[],
    };
  }

  public async componentDidMount(): Promise<void> {
    const remindersArray: AdwReminder[] = await this.getReminders();
    const nwieId: string = await this.spUserDataService.getNwieID();
    const sitesAtoZArray: AdwAtoZLink[] = await this.getUserSites(nwieId);

    let _insideEventsAndPayrolls: InsideEvent;
    let adwEventArray: AdwEvent[];
    let adwPayDayArray: AdwPayDay[];
    const displayOptionValues: IDisplayOption[] = this.getDisplayOptions();

    if (displayOptionValues && displayOptionValues[2] && displayOptionValues[2].isDisplay) {
      _insideEventsAndPayrolls = await this.getEventsAndPayroll(nwieId);
      console.log("_insideEventsAndPayrolls >> ", _insideEventsAndPayrolls);
      adwEventArray = this.getAdwEvents(_insideEventsAndPayrolls);
      adwPayDayArray = this.getAdwPayDays(_insideEventsAndPayrolls);
      this.setState({
        eventsArray: adwEventArray,
        payDayArray: adwPayDayArray,
      });
      console.log("adwEventArray :", adwEventArray);
      console.log("adwPayDayArray :", adwPayDayArray);
    }
    window.addEventListener("resize", this.handleResize);
    this.setState({
      siteArray: sitesAtoZArray,
      reminderArray: remindersArray,
      displayOptions: displayOptionValues,
    });
  }

  public async componentWillUnmount(): Promise<void> {
    window.addEventListener("resize", this.handleResize);
  }

  /* Map Inside A to Z Site Data to React Data Types  */
  private getUserSites(nwieId: string): Promise<AdwAtoZLink[]> {
    let insideSitesAtoZPromise: Promise<AdwAtoZLink[]>;
    insideSitesAtoZPromise = this.insideDataService.getUserPreferences(nwieId).then(insideData => {
      const insideSitesAtoZArray: InsideAtoZSite[] = insideData.aToZFavorites;
      const adwAtoZSitesArray: AdwAtoZLink[] = insideSitesAtoZArray.map(insideSite => {
        return new AdwAtoZLink(insideSite);
      });
      return adwAtoZSitesArray;
    });
    return insideSitesAtoZPromise;
  }

  private getReminders(): Promise<AdwReminder[]> {
    let reminderPromise: Promise<AdwReminder[]>;
    const siteUrl: string = this.environmentService.getSiteUrl();

    reminderPromise = this.spApiService.getListItems(this.props.context, "Reminders", siteUrl).then((spReminders: SpReminder[]) => {
      const spReminderArray: SpReminder[] = spReminders;
      const adwReminderArray: AdwReminder[] = spReminderArray.map(spReminder => {
        return new AdwReminder(spReminder);
      });
      return adwReminderArray;
    });
    return reminderPromise;
  }

  private getEventsAndPayroll(nwieId: string): Promise<InsideEvent> {
    let insideEventsPromise: Promise<InsideEvent>;
    insideEventsPromise = this.insideDataService.getEventsAndPayroll(nwieId);
    return insideEventsPromise;
  }

  private getAdwEvents(insideEvent: InsideEvent): AdwEvent[] {
    let adwEventArray: AdwEvent[];
    let insideEvents: InsideEventDetails[] = insideEvent.events;
    adwEventArray = insideEvents.map(insideEventDetail => {
      return new AdwEvent(insideEventDetail);
    });
    return adwEventArray;
  }

  private getAdwPayDays(insideEvent: InsideEvent): AdwPayDay[] {
    let adwPayDays: AdwPayDay[];
    let insidePayDays: InsidePayDay[] = insideEvent.paydays;
    let limitFivePayDays: InsidePayDay[] = insidePayDays.length > 5 ? insidePayDays.slice(insidePayDays.length - 5) : insidePayDays;
    // let insidePayDays: InsideEventDetails[] = insideEvent.paydays;
    adwPayDays = limitFivePayDays.map(insidePayDay => {
      return new AdwPayDay(insidePayDay);
    });
    return adwPayDays;
  }

  // event - If not Tablet, Mobile
  private handleResize = () => {
    this.setState({
      displayOptions: this.getDisplayOptions(),
    });
    if (this.state.displayOptions && this.state.displayOptions[2] && this.state.displayOptions[2].isDisplay) {
      this.componentDidMount();
    }
  };

  private getDisplayOptions = (): IDisplayOption[] => {
    return [
      { deviceName: "mobile", isDisplay: this.detecMobile() },
      { deviceName: "tablet", isDisplay: this.detectablet() },
      { deviceName: "desktop", isDisplay: this.detecDesktop() },
    ];
  };

  private detecMobile = (): boolean => {
    if (window.innerWidth <= 767) {
      return true;
    } else {
      return false;
    }
  };

  private detectablet = (): boolean => {
    if (window.innerWidth >= 768 && window.innerWidth <= 1024) {
      return true;
    } else {
      return false;
    }
  };

  private detecDesktop = (): boolean => {
    if (window.innerWidth >= 1025) {
      return true;
    } else {
      return false;
    }
  };
  // end of Event

  public render(): React.ReactElement<ISitesAtoZProps> {
    const { displayOptions } = this.state;
    return (
      <div className={styles.sitesAtoZcontainer}>
        {/* Events for Desktop only */}
        {displayOptions &&
          displayOptions[2] &&
          displayOptions[2].isDisplay && (
            <div className={styles.events}>
              <Events
                eventClasses="sitesAtoZcontainer"
                eventArray={this.state.eventsArray}
                payDayArray={this.state.payDayArray}
                displayOptions={this.state.displayOptions}
              />
            </div>
          )}
        {/* End of Event */}
        <div className={styles.reminders}>
          <Reminders reminderArray={this.state.reminderArray} />
        </div>
        <div className={styles.favorites}>
          <AtoZ aToZArray={this.state.siteArray} />
        </div>
      </div>
    );
  }
}

export default SitesAtoZview;
