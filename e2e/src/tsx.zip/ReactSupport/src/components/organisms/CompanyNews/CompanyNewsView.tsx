import * as React from "react";
import styles from "./CompanyNews.module.scss";
import { ICompanyNewsProps } from "../../../webparts/companyNews/components/ICompanyNewsProps";
import { ISpApiService } from "../../../interfaces/ISpApiService";
import SpApiService from "../../../services/SpApiService";
import AdwNewsStory from "../../../types/CompanyNewsTypes/AdwNewsStory";
import { SpNewsStory } from "../../../types/CompanyNewsTypes/SpNewsStory";
import FeaturedStory from "../../molecules/FeaturedStory/FeaturedStory";
import StorySnapshot from "../../molecules/StorySnapshot/StorySnapshot";
import FeaturedStoryLink from "../../molecules/FeaturedStoryLink/FeaturedStoryLink";
import MoreNewsLink from "../../molecules/MoreNewsLink/MoreNewsLink";
import CommonToolsView from "../CommonTools/CommonToolsView";
import GoToLink from "../../molecules/GoToLink/GoToLink";
import { SpCommonTool } from "../../../types/CommonToolsTypes/SpCommonTool";
import AdwCommonTool from "../../../types/CommonToolsTypes/AdwCommonTool";
import { InsideUserData } from "../../../types/InsideUserData";
import { IInsideDataService } from "../../../interfaces/IInsideDataService";
import IUserDataService from "../../../interfaces/IUserDataService";
import InsideDataService from "../../../services/InsideDataService";
import SpUserDataService from "../../../services/SpUserDataService";
import IEnvironmentService from "../../../interfaces/IEnvironmentService";
import EnvironmentService from "../../../services/EnvironmentService";
/* Event - for iPad */
import Events from "../../organisms/Events/Events";
import { InsideEvent } from "../../../types/EventTypes/InsideEvent";
import { InsideEventDetails } from "../../../types/EventTypes/InsideEventDetails";
import { InsidePayDay } from "../../../types/EventTypes/InsidePayDay";
import AdwEvent from "../../../types/EventTypes/AdwEvent";
import AdwPayDay from "../../../types/EventTypes/AdwPayDay";
export interface IDisplayOption {
  deviceName: string;
  isDisplay: boolean;
}
/* end of Event */

export interface ICompanyNewState {
  adwCommonTools: AdwCommonTool[];
  featuredStory: AdwNewsStory;
  preferredTools: string;
  topStories: AdwNewsStory[];
  insideEventsAndPayrolls: InsideEvent;
  eventsArray: AdwEvent[];
  payDayArray: AdwPayDay[];
  isTablet: boolean;
  displayOptions: IDisplayOption[];
  toolsToDisplay: AdwCommonTool[];
}

class CompanyNewsView extends React.Component<ICompanyNewsProps, ICompanyNewState> {
  private _insideDataService: IInsideDataService;
  private _spApiService: ISpApiService;
  private _spUserDataService: IUserDataService;
  private _enviornmentService: IEnvironmentService;
  constructor(props: ICompanyNewsProps) {
    super(props);
    this._insideDataService = new InsideDataService();
    this._spApiService = new SpApiService();
    this._spUserDataService = new SpUserDataService(this.props.context);
    this._enviornmentService = new EnvironmentService();
    this.state = {
      adwCommonTools: [] as AdwCommonTool[],
      featuredStory: {} as AdwNewsStory,
      preferredTools: "",
      topStories: [] as AdwNewsStory[],
      insideEventsAndPayrolls: [] as any,
      eventsArray: [] as AdwEvent[],
      payDayArray: [] as AdwPayDay[],
      isTablet: false,
      displayOptions: [] as IDisplayOption[],
      toolsToDisplay: [] as AdwCommonTool[],
    };
  }

  public async componentDidMount(): Promise<void> {
    const stories: AdwNewsStory[] = await this.getStories();
    const insideUserData: InsideUserData = await this.getUserPreferences();
    const adwCommonTools: AdwCommonTool[] = await this.getCommonTools(insideUserData);
    const nwieId: string = await this._spUserDataService.getNwieID();

    let _insideEventsAndPayrolls: InsideEvent;
    let adwEventArray: AdwEvent[];
    let adwPayDayArray: AdwPayDay[];
    const displayOptionValues: IDisplayOption[] = this.getDisplayOptions();

    if (displayOptionValues && displayOptionValues[0] && (displayOptionValues[0].isDisplay || displayOptionValues[1].isDisplay)) {
      _insideEventsAndPayrolls = await this.getEventsAndPayroll(nwieId);
      adwEventArray = this.getAdwEvents(_insideEventsAndPayrolls);
      adwPayDayArray = this.getAdwPayDays(_insideEventsAndPayrolls);
      this.setState({
        eventsArray: adwEventArray,
        payDayArray: adwPayDayArray,
      });
    }
    window.addEventListener("resize", this.handleResize);
    this.setState({
      adwCommonTools: adwCommonTools,
      featuredStory: stories.splice(0, 1)[0],
      preferredTools: insideUserData.preferredCommonTools,
      topStories: stories,
      displayOptions: displayOptionValues,
      toolsToDisplay: this.determineDefaultOrPreferedTools(adwCommonTools, insideUserData.preferredCommonTools),
    });
  }

  public async componentWillUnmount(): Promise<void> {
    window.addEventListener("resize", this.handleResize);
  }

  private getUserPreferences = async (): Promise<InsideUserData> => {
    const nwieId: string = await this._spUserDataService.getNwieID();
    return await this._insideDataService.getUserPreferences(nwieId);
  };

  private getCommonTools = async (insideUserData: InsideUserData): Promise<AdwCommonTool[]> => {
    const spCommonTools: SpCommonTool[] = await this._spApiService.getListItemsWithAttachments<SpCommonTool>(
      this.props.context,
      "Common Tools",
    );
    return spCommonTools.map(tool => new AdwCommonTool(tool, insideUserData));
  };

  private determineDefaultOrPreferedTools = (adwCommonTools: AdwCommonTool[], preferredTools: string): AdwCommonTool[] => {
    if (preferredTools) {
      const preferredToolsArray: number[] = this.convertPreferredToolsToArray(preferredTools);
      return preferredToolsArray.map(preferredToolId => adwCommonTools.find(tool => tool.ID === preferredToolId));
    } else {
      return adwCommonTools.filter(tool => tool.DefaultTool || tool.RequiredTool);
    }
  };

  private convertPreferredToolsToArray = (preferredTools: string): number[] => {
    if (preferredTools) {
      const preferredToolsArray: string[] = preferredTools.split(", ");
      return preferredToolsArray.map(preferredTool => parseInt(preferredTool, 0));
    } else {
      return undefined;
    }
  };

  private getStories = async (): Promise<AdwNewsStory[]> => {
    const spNewsStories: SpNewsStory[] = await this._spApiService.getListItemsWithAttachments<SpNewsStory>(
      this.props.context,
      "Company News",
    );
    const adwNewsStories: AdwNewsStory[] = this.buildAdwNewsStories(spNewsStories);
    const filteredAdwNewsStories: AdwNewsStory[] = this.filterNewsStories(adwNewsStories);
    filteredAdwNewsStories.sort((storyA, storyB) => new Date(storyB.publishDate).getTime() - new Date(storyA.publishDate).getTime());
    // only return top 5 articles
    return filteredAdwNewsStories.splice(0, 5);
  };

  private buildAdwNewsStories = (spNewsStories: SpNewsStory[]): AdwNewsStory[] => {
    return spNewsStories.map((newsStory: SpNewsStory) => {
      return new AdwNewsStory(newsStory);
    });
  };

  private filterNewsStories = (adwNewsStories: AdwNewsStory[]): AdwNewsStory[] => {
    const newStories: AdwNewsStory[] = this.filterNewsStoriesByApprovalStatus(adwNewsStories);
    return this.filterNewsStoriesByDate(newStories);
  };

  private filterNewsStoriesByDate = (adwNewsStories: AdwNewsStory[]): AdwNewsStory[] => {
    const todaysDate: Date = new Date();
    return adwNewsStories.filter(newsStory => +new Date(newsStory.publishDate) < todaysDate.getTime());
  };

  private filterNewsStoriesByApprovalStatus = (adwNewsStories: AdwNewsStory[]): AdwNewsStory[] => {
    return adwNewsStories.filter(adwNewsStory => adwNewsStory.approvalStatus === true);
  };

  /* Events - for iPad, Mobile */
  private getEventsAndPayroll(nwieId: string): Promise<InsideEvent> {
    let insideEventsPromise: Promise<InsideEvent>;
    insideEventsPromise = this._insideDataService.getEventsAndPayroll(nwieId);
    return insideEventsPromise;
  }

  private getAdwEvents(insideEvent: InsideEvent): AdwEvent[] {
    let adwEventArray: AdwEvent[];
    let insideEvents: InsideEventDetails[] = insideEvent.events;
    adwEventArray = insideEvents.map(insideEventDetail => {
      return new AdwEvent(insideEventDetail);
    });
    return adwEventArray;
  }

  private getAdwPayDays(insideEvent: InsideEvent): AdwPayDay[] {
    let adwPayDays: AdwPayDay[];
    let insidePayDays: InsidePayDay[] = insideEvent.paydays;
    // insideEvent.paydays;
    adwPayDays = insidePayDays.map(insidePayDay => {
      return new AdwPayDay(insidePayDay);
    });
    return adwPayDays;
  }

  // event - If not Tablet, Mobile
  private handleResize = () => {
    console.log("handleResize called");

    this.setState({
      displayOptions: this.getDisplayOptions(),
    });

    if (
      this.state.displayOptions &&
      this.state.displayOptions[0] &&
      (this.state.displayOptions[0].isDisplay || this.state.displayOptions[1].isDisplay)
    ) {
      this.componentDidMount();
    }
  };

  private getDisplayOptions = (): IDisplayOption[] => {
    return [
      { deviceName: "mobile", isDisplay: this.detecMobile() },
      { deviceName: "tablet", isDisplay: this.detectablet() },
      { deviceName: "desktop", isDisplay: this.detecDesktop() },
    ];
  };

  private detecMobile = (): boolean => {
    if (window.innerWidth <= 767) {
      return true;
    } else {
      return false;
    }
  };

  private detectablet = (): boolean => {
    if (window.innerWidth >= 768 && window.innerWidth <= 1024) {
      return true;
    } else {
      return false;
    }
  };

  private detecDesktop = (): boolean => {
    if (window.innerWidth >= 1025) {
      return true;
    } else {
      return false;
    }
  };
  // end of Event

  public render(): React.ReactElement<ICompanyNewsProps> {
    const { adwCommonTools, featuredStory, preferredTools, topStories, toolsToDisplay, displayOptions } = this.state;
    const siteUrl: string = this._enviornmentService.getSiteUrl();
    const pageUrl: string = `${siteUrl}/SitePages/CustomizeTools.aspx`;

    return (
      <div className={styles.companyNews}>
        <div className={styles.newsStories}>
          {topStories.map(story => <StorySnapshot story={story} headingStyles={styles.heading} dateStyles={styles.date} />)}
        </div>
        <MoreNewsLink linkStyles={styles.link} moreNewsStyles={styles.moreNews} moreNewsArrowStyles={styles.moreNewsArrow} />
        <FeaturedStory
          featuredStory={featuredStory}
          featuredStorySyles={styles.featuredStory}
          headingStyles={styles.heading}
          dateStyles={styles.date}
        />
        <FeaturedStoryLink
          arrowStyles={styles.arrow}
          featuredStory={featuredStory}
          storyLinkStyles={styles.storyLink}
          linkTextStyles={styles.linkText}
        />
        <CommonToolsView
          commonToolsStyles={styles.commonTools}
          showEditingTools={false}
          preferredTools={preferredTools}
          defaultOrPreferredTools={toolsToDisplay}
        />
        <div className={styles.customizeTools}>
          <GoToLink linkText="Customize Tools" target={"new"} url={pageUrl} />
        </div>
        {/* Events for iPad, Mobile */}
        {displayOptions &&
          displayOptions[0] &&
          (displayOptions[0].isDisplay || displayOptions[1].isDisplay) && (
            <div className={styles.events}>
              <Events
                eventClasses="companyNews"
                eventArray={this.state.eventsArray}
                payDayArray={this.state.payDayArray}
                displayOptions={this.state.displayOptions}
              />
            </div>
          )}
        {/* End of Event */}
      </div>
    );
  }
}

export default CompanyNewsView;
