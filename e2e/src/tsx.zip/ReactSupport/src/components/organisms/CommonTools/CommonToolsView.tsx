import * as React from "react";
import styles from "./CommonTools.module.scss";
import AdwCommonTool from "../../../types/CommonToolsTypes/AdwCommonTool";
import Tool from "../../molecules/Tool/Tool";
import ToggleArrowButton from "../../molecules/ToggleArrowButton/ToggleArrowButton";

export interface ICommonToolsProps {
  commonToolsStyles?: string;
  showEditingTools?: boolean;
  tools?: AdwCommonTool[];
  preferredTools?: string;
  toolPickerClickEvent?: (e: React.MouseEvent<HTMLDivElement>) => void;
}

export interface ICommonToolsState {
  toolsToDisplay: AdwCommonTool[];
  pageOfItems: AdwCommonTool[];
  isToggleDisable: boolean;
  pageNumber: number;
}

class CommonToolsView extends React.Component<ICommonToolsProps, ICommonToolsState> {
  constructor(props: ICommonToolsProps) {
    super(props);
    this.state = {
      toolsToDisplay: [] as AdwCommonTool[],
      pageOfItems: [] as AdwCommonTool[],
      isToggleDisable: false as boolean,
      pageNumber: 1,
    };
    this.handleResize = this.handleResize.bind(this);
  }

  public async componentWillReceiveProps(nextProps: any): Promise<void> {
    const { tools, preferredTools } = nextProps;
    if (tools.length > 0) {
      const toolsToDisplay: AdwCommonTool[] = this.buildToolsToDisplayArray(tools, this.convertPreferredToolsToArray(preferredTools));
      let displayArray: AdwCommonTool[] = this.getDisplayArray(toolsToDisplay);
      this.setState({
        toolsToDisplay: toolsToDisplay,
        pageOfItems: displayArray,
        isToggleDisable: toolsToDisplay.length <= 5 ? true : false,
      });
    }
  }

  private getDisplayArray(toolsArray: AdwCommonTool[]): AdwCommonTool[] {
    let displayArray: AdwCommonTool[];
    if (this.state.pageNumber === 1) {
      displayArray = toolsArray.slice(0, 5);
    } else {
      displayArray = toolsArray.slice(5, 10);
    }
    return displayArray;
  }

  public async componentDidMount(): Promise<void> {
    window.addEventListener("resize", this.handleResize);
  }

  public async componentWillUnmount(): Promise<void> {
    window.addEventListener("resize", this.handleResize);
  }

  private handleResize = () => {
    const { toolsToDisplay } = this.state;
    let displayArray: AdwCommonTool[] = this.getDisplayArray(toolsToDisplay);
    if (this.detectmob()) {
      this.setState({
        pageOfItems: displayArray,
      });
    } else {
      this.setState({ pageOfItems: toolsToDisplay });
    }
  };

  private detectmob = (): boolean => {
    if (window.innerWidth <= 767) {
      return true;
    } else {
      return false;
    }
  };

  public getData = (pageOfItems: AdwCommonTool[], pageNumber: number): void => {
    this.setState({
      pageOfItems: pageOfItems,
      pageNumber: pageNumber,
    });
  };

  convertPreferredToolsToArray = (preferredTools: string): number[] => {
    if (preferredTools) {
      const preferredToolsArray: string[] = preferredTools.split(", ");
      return preferredToolsArray.map(preferredTool => parseInt(preferredTool, 0));
    } else {
      return undefined;
    }
  };

  determineIfEmptyToolsExist = (tools: AdwCommonTool[]): AdwCommonTool[] => {
    const { showEditingTools } = this.props;
    if (tools.length < 10 && showEditingTools) {
      for (let i: number = tools.length; i < 10; i++) {
        const emptyTool: AdwCommonTool = new AdwCommonTool(null, null);
        tools.push(emptyTool);
      }
      return tools;
    } else {
      return tools;
    }
  };

  buildToolsToDisplayArray = (tools: AdwCommonTool[], preferredTools: number[]): AdwCommonTool[] => {
    if (preferredTools) {
      const toolsToDisplay: AdwCommonTool[] = tools.filter(tool => preferredTools.includes(tool.ID) || tool.RequiredTool);
      return this.determineIfEmptyToolsExist(toolsToDisplay);
    } else {
      const toolsToDisplay: AdwCommonTool[] = tools.filter(tool => tool.DefaultTool || tool.RequiredTool);
      return this.determineIfEmptyToolsExist(toolsToDisplay);
    }
  };

  handleCloseButtonClick = (): void => {
    window.history.back();
  };

  public render(): React.ReactElement<ICommonToolsProps> {
    const { commonToolsStyles, showEditingTools, tools } = this.props;
    const commonToolsClasses: string = commonToolsStyles
      ? `${commonToolsStyles} ${styles.CommonToolsWrapper}`
      : `${styles.CommonToolsWrapper}`;
    const { toolsToDisplay, pageOfItems, isToggleDisable } = this.state;
    const numberOfNewTools: number = AdwCommonTool.getNumberOfNewTools(tools);
    const isMobile: boolean = this.detectmob();
    const firstFiveTools: any = toolsToDisplay.slice(0, 5);
    const nextFiveTools: any = toolsToDisplay.slice(5, 10);

    return (
      <div className={commonToolsClasses}>
        <div className={styles.toolsHeading}>
          <h4 className={styles.title}>Tools</h4>
          {!showEditingTools ? (
            <div className={styles.newToolsOrArrows}>
              <ToggleArrowButton
                disabled={isToggleDisable}
                onLeftArrowClick={() => this.getData(firstFiveTools, 1)}
                onRightArrowClick={() => this.getData(nextFiveTools, 2)}
              />
              {numberOfNewTools > 0 ? <span className={styles.newTools}>{numberOfNewTools} new available</span> : null}
            </div>
          ) : showEditingTools ? (
            <div className={styles.closeButton} onClick={this.handleCloseButtonClick}>
              <div className={styles.closeX} />
              <span className={styles.closeText}>CLOSE</span>
            </div>
          ) : null}
        </div>
        {showEditingTools ? <span className={styles.customizeToolsText}>Customize your tools to fit you everyday needs</span> : null}
        <div className={styles.toolsDisplay}>
          {!showEditingTools
            ? (isMobile ? pageOfItems : toolsToDisplay).map(tool => (
                <Tool tool={tool} availableTools={false} customizeTools={showEditingTools} />
              ))
            : toolsToDisplay.map(tool => (
                <Tool
                  tool={tool}
                  availableTools={false}
                  customizeTools={showEditingTools}
                  toolStyles={tool.ImageUrl[0].length > 0 ? "" : styles.emptyTool}
                  toolPickerClickEvent={e => this.props.toolPickerClickEvent(e)}
                  toolsList={tools}
                />
              ))}
        </div>
      </div>
    );
  }
}

export default CommonToolsView;
