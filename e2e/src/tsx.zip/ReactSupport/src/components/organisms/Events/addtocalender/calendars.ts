import Utils from "./utils";

export default class Calendars {
  private utils: any;
  constructor() {
    this.utils = new Utils();
  }
  public getYahooCalendarUrl(data: any): string {
    let yahooCalendarUrl: string = "http://calendar.yahoo.com/?v=60&view=d&type=20";
    const duration: any = this.utils.getHoursDuration(data.startDate, data.endDate);

    yahooCalendarUrl += "&TITLE=" + data.title;
    yahooCalendarUrl += "&ST=" + data.startDate + "&DUR=" + duration;
    yahooCalendarUrl += "&DESC=" + data.description;
    yahooCalendarUrl += "&in_loc=" + data.location;

    return yahooCalendarUrl;
  }

  public getMicrosoftCalendarUrl(data: any): string {
    let microsoftCalendarUrl: string = "http://calendar.live.com/calendar/calendar.aspx?rru=addevent";
    microsoftCalendarUrl += "&summary=" + data.title;
    microsoftCalendarUrl += "&dtstart=" + data.startDate + "&dtend=" + data.endDate;
    microsoftCalendarUrl += "&description=" + data.description;
    microsoftCalendarUrl += "&location=" + data.location;

    return microsoftCalendarUrl;
  }

  public getGoogleCalendarUrl(data: any): string {
    let googleCalendarUrl: string = "https://www.google.com/calendar/render?action=TEMPLATE";
    googleCalendarUrl += "&text=" + data.title;
    googleCalendarUrl += "&dates=" + data.startDate + "/" + data.endDate;
    googleCalendarUrl += "&details=" + data.description;
    googleCalendarUrl += "&location=" + data.location;

    return googleCalendarUrl;
  }

  public getIcsCalendar(data: any): any {
    return [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "BEGIN:VEVENT",
      "CLASS:PUBLIC",
      "DESCRIPTION:" + this.utils.formatIcsText(data.description, 62),
      "DTSTART:" + data.startDate,
      "DTEND:" + data.endDate,
      "LOCATION:" + this.utils.formatIcsText(data.location, 64),
      "SUMMARY:" + this.utils.formatIcsText(data.title, 66),
      "TRANSP:TRANSPARENT",
      "END:VEVENT",
      "END:VCALENDAR",
      "UID:" + this.utils.getUid(),
      "DTSTAMP:" + this.utils.getTimeCreated(),
      "PRODID:angular-addtocalendar",
    ].join("\n");
  }
}
