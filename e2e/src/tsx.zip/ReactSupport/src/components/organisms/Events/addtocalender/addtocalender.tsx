import * as FileSaver from "file-saver";
import * as React from "react";
import Calendars from "./calendars";
import "./addtocalender.scss";
import Utils from "./utils";

export interface IAddToCalender {
  startDate: string;
  endDate: string;
  title: string;
  location: string;
  description: string;
  icon: string;
}
class AddtoCalender extends React.Component<IAddToCalender> {
  private calendars: any;
  private utils: any;
  private dates: any;
  private calendarUrl: any;
  private urlData: any;
  private icsData: any;
  private timezone: any;
  private bgStyle: any;

  constructor(props: IAddToCalender) {
    super(props);
    this.dates = {
      endDate: this.props.endDate,
      startDate: this.props.startDate,
    };
    this.utils = new Utils();
    this.calendars = new Calendars();
    const calendarIcon: string = this.props.icon;
    this.bgStyle = {
      backgroundImage: "url(" + calendarIcon + ")",
    };
    ////   this.bgStyle = {
    //     backgroundImage: "url(" + calendarIcon + ")",
    //   };
  }

  public setTimesFromFormat = () => {
    ["startDate", "endDate"].forEach(t => {
      this.dates[t] = this.utils.toUniversalTime(this[t], this.timezone);
    });
  };

  public buildUrl = () => {
    this.urlData = Object.assign(this.getSanitizedData(), this.dates);
    this.icsData = Object.assign(this.getSanitizedData(), this.dates);

    this.calendarUrl = {
      google: this.calendars.getGoogleCalendarUrl(this.urlData),
      icalendar: this.calendars.getIcsCalendar(this.icsData),
      microsoft: this.calendars.getMicrosoftCalendarUrl(this.urlData),
      yahoo: this.calendars.getYahooCalendarUrl(this.urlData),
    };
  };

  public getSanitizedData = () => {
    const urlData: any = {};
    Object.keys(this.props).forEach(key => {
      urlData[key] = encodeURIComponent(this.props[key] || "");
    });
    return urlData;
  };

  public dlIcal = () => {
    const fileName: any = this.utils.getIcsFileName(this.props.title);
    const icsData: any = this.calendarUrl.icalendar;
    const icsBlob: any = this.utils.getIcsBlob(icsData);
    FileSaver.saveAs(icsBlob, fileName);
  };

  public componentDidMount(): void {
    this.buildUrl();
  }
  public render(): React.ReactElement<IAddToCalender> {
    return (
      <div className="eventDetailOutlook" onClick={this.dlIcal}>
        <div className="eventCalenderIcon" style={this.bgStyle} />
        <div className="eventLinkText">Add to Outlook</div>
      </div>
    );
    // return <a onClick={this.dlIcal}>Add to Outlook</a>;
  }
}

export default AddtoCalender;
 