import * as moment from "moment";

export default class Utils {
  /**
   * Return 12-hour format to 24-hour.
   *
   * @param  {Number} hours
   * @return {String}
   */
  // static getMilitaryHours(hours) {
  public getMilitaryHours(hours: number): string {
    if (hours % 1 === 0.5) {
      return `${Math.floor(hours)}30`;
    }
    return `${Math.round(hours)}00`;
  }

  /**
   * Gets the duration between dates.
   *
   * @param  {String} startDate
   * @param  {String} endDate
   * @param  {Number} timezone
   * @return {String}
   */
  public getHoursDuration(startDate: string, endDate: string, timezone?: number): string {
    const start: any = moment(startDate);
    const end: any = moment(endDate);

    if (timezone) {
      start.utcOffset(timezone);
      end.utcOffset(timezone);
    }

    const hours: any = moment.duration(end.diff(start)).asHours();

    return this.getMilitaryHours(hours);
  }

  /**
   * Removes line breaks and ensures that the string is no
   * longer than maxLength chars (or 75 chars if none specified).
   *
   * @param  {String} s         string to sanitize
   * @param  {Number} maxLength index of string to truncate at
   * @return {String}
   */
  public formatIcsText(str: string, maxLength: number): string {
    if (!str) {
      return "";
    }
    str = str.replace(/\n/g, "\\n");
    str = decodeURIComponent(str);
    str = str.substring(0, maxLength);

    return str;
  }

  /**
   * Format time as a universal timestamp format w.r.t. the given timezone.
   *
   * @param  {String} timestamp valid RFC-2822 string timestamp
   * @param  {String} timezone  tz offset (in minutes) (optional)
   * @return {String}
   */
  public toUniversalTime(timestamp: string, timezone: string): string {
    const dt: any = moment(timestamp);

    if (timezone) {
      dt.utcOffset(timezone);
    }
    return dt.format("YYYYMMDDTHHmmss");
  }

  /**
   * The name of the file will be the event title with alphanumeric chars
   * having the extension `.ics`.
   *
   * @param  {String} icsData
   * @return {Blob}
   */
  public getIcsBlob(icsData: string): Blob {
    return new Blob([icsData], {
      type: "application/octet-stream",
    });
  }

  /**
   * Transforms given string to be valid file name.
   *
   * @param  {String} title
   * @return {String}
   */
  public getIcsFileName(title: string): string {
    if (!title) {
      return "event.ics";
    }
    console.log("getIcsFileName --> ", title);
    return `${title.replace(/[^\w ]+/g, "")}.ics`;
  }

  /**
   * Returns a random base 36 hash for iCal UID.
   *
   * @return {String}
   */
  public getUid(): string {
    return Math.random()
      .toString(36)
      .substr(2);
  }

  /**
   * Returns a universal timestamp of current time.
   *
   * @return {String}
   */
  public getTimeCreated(): string {
    return moment().format("YYYYMMDDTHHmmss");
  }
}
