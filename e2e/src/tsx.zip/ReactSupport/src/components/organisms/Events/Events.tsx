import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import * as moment from "moment";
import styles from "./Events.module.scss";
import NoResults from "../../molecules/NoResults/NoResults";
import Image from "../../atoms/Image/Image";
import GoToLink from "../../molecules/GoToLink/GoToLink";
import AddtocalendarButton from "../../molecules/AddtocalendarButton/addtocalender";
import EventDetails from "../../../types/EventListTypes/EventDetails"; // retire this, delete it
import AdwEvent from "../../../types/EventTypes/AdwEvent";
import AdwPayDay from "../../../types/EventTypes/AdwPayDay";
import AdwCampaignBanner from "../../../types/CampaignBannerTypes/AdwCampaignBanner";
import EnvironmentService from "../../../services/EnvironmentService";
import SpApiService from "../../../services/SpApiService";
import { SpCampaignBanner } from "../../../types/CampaignBannerTypes/SpCampaignBanner";

export interface IDisplayOption {
  deviceName: string;
  isDisplay: boolean;
}

export interface IEventsProps {
  eventClasses?: string;
  eventArray: EventDetails[];
  payDayArray: AdwPayDay[];
  displayOptions: IDisplayOption[];
}
export interface IEventsState {
  displayCampaign?: boolean;
  eventClasses?: string;
  eventArray: EventDetails[];
  payDayArray: AdwPayDay[];
  displayOptions: IDisplayOption[];
  campaignImage?: string;
  noResultsImage?: string;
  noResultsText?: string;
  linkToCalendar?: string;
}

class Events extends React.Component<IEventsProps, IEventsState> {
  private environmentService: EnvironmentService;
  private spApiService: SpApiService;
  constructor(props: IEventsProps) {
    super(props);
    this.environmentService = new EnvironmentService();
    const siteUrl: string = this.environmentService.getSiteUrl();

    this.spApiService = new SpApiService(siteUrl);
    this.state = {
      displayCampaign: false,
      eventClasses: "",
      eventArray: [],
      payDayArray: [],
      displayOptions: [],
      campaignImage: "",
      noResultsImage: "",
      noResultsText: "",
      linkToCalendar: "",
    };
  }

  private filterBanners(bannerArray: AdwCampaignBanner[]): AdwCampaignBanner[] {
    const todaysDate: Date = new Date();
    todaysDate.setHours(0, 0, 0, 0);
    const nonExpiredBannnersArray: AdwCampaignBanner[] = bannerArray.filter(
      bannerArray => +new Date(bannerArray.EndDate) >= todaysDate.getTime(),
    );
    console.log("nonExpiredBannnersArray >> ", nonExpiredBannnersArray);
    return nonExpiredBannnersArray;
  }

  public async componentDidMount(): Promise<void> {
    /* let campaignBannerArray: AdwCampaignBanner[] = await this.getCampaignBanner();
    console.log("campaignBannerArray >> ", campaignBannerArray); */
    const campaignBannerArray: AdwCampaignBanner[] = await this.getCampaignBanner();
    console.log("campaignBannerArray >> ", campaignBannerArray);
    const banner: AdwCampaignBanner[] = this.filterBanners(campaignBannerArray);
    console.log("banner >> ", banner);
    console.log("banner image >> ", banner[0].ImagePath[0]);
    const _displayCampaign: boolean = this.isDisplayCampaign(this.props.displayOptions); // false;
    const _eventArray: EventDetails[] = this.props.eventArray
      ? this.createMockData(this.props.eventArray, this.props.displayOptions, _displayCampaign)
      : [];
    const _eventClasses: string = this.setStylesFromParent(this.props.eventClasses);
    const _campaignImage: string = banner[0].ImagePath[0]; // require("../../../assets/images/pic1.png");
    const _noResultsImage: string = require("../../../assets/images/calendar-gray-icon.png");

    const _noResultsText: string = this.getNoResultsText();
    const _linkToCalendar: string = "https://dev-inside.nwie.net/inside-web/companyEventCalendar/openEventCalendar";

    this.setState({
      displayCampaign: _displayCampaign,
      eventArray: _eventArray,
      eventClasses: _eventClasses,
      campaignImage: _campaignImage,
      noResultsImage: _noResultsImage,
      noResultsText: _noResultsText,
      linkToCalendar: _linkToCalendar,
    });
  }

  /***/

  public isDisplayCampaign(displayOptions: IDisplayOption[]): boolean {
    if (displayOptions && displayOptions[2] && displayOptions[2].isDisplay) {
      return true;
    }
    return false;
  }
  public isTablet(displayOptions: IDisplayOption[]): boolean {
    if (displayOptions && displayOptions[1] && displayOptions[1].isDisplay) {
      return true;
    }
    return false;
  }
  public showResultsPayDays(payDayArray: AdwPayDay[]): JSX.Element {
    let returnElement: JSX.Element = null;
    if (payDayArray && payDayArray.length > 0) {
      const payDayReturnElement: JSX.Element = (
        <div className={styles.nextpayday}>
          <div className={styles.npItem + " " + styles.npLabel}>Next Paydays:</div>
          <ul>
            {payDayArray.map((pd, index) => (
              <li className={styles.npItem}>
                <a>{pd.payDay}</a>
              </li>
            ))}
          </ul>
        </div>
      );
      returnElement = payDayReturnElement;
    }
    return returnElement;
  }

  public showResultsOrMessage(eventArray: EventDetails[], linkToCalendar: string): JSX.Element {
    let returnElement: JSX.Element = null;
    if (eventArray && eventArray.length > 0) {
      const calendarIcon: string = require("../../../assets/images/calendar-icon.png");
      console.log("eventArray >> ", eventArray);
      const userEvents: JSX.Element = (
        <ul>
          {eventArray.map((ec, index) => (
            <li id={`event-site-${index}`} onClick={() => this.openWindow(ec.Url)}>
              <div className={styles.eventWrapper}>
                <div className={styles.eventCalender}>
                  <div className={styles.eventCalenderContent}>
                    <div className={styles.eventCalenderDay}>{ec.Day}</div>
                    <div className={styles.eventCalenderDate}>{ec.Date}</div>
                    <div className={styles.eventCalenderMonth}>{ec.Month}</div>
                  </div>
                </div>
                <div className={styles.eventDetail}>
                  <div className={styles.eventDetailContent}>
                    <div>
                      <div className={styles.eventDetailTitle}>{ec.Title}</div>
                      <div className={styles.eventDetailTime}>{this.getTime(ec.StartDate, ec.EndDate)}</div>
                    </div>
                    <AddtocalendarButton
                      startDate={ec.StartDate}
                      endDate={ec.EndDate}
                      title={ec.Title}
                      location={ec.Location}
                      description={ec.Description}
                      icon={calendarIcon}
                    />
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      );
      returnElement = userEvents;
    } else {
      const noResultsImage: string = require("../../../assets/images/star.png");
      const noResultsText: string = this.getNoResultsText();
      const noResults: JSX.Element = <NoResults imagePath={noResultsImage} textForDisplay={noResultsText} />;
      returnElement = noResults;
    }

    return returnElement;
  }

  public getTime(StartDate: string, EndDate: string): string {
    let formattedTime: string = `All Day`;
    if (StartDate && EndDate && StartDate !== EndDate) {
      const startDate: any = moment(StartDate).format("LT");
      const endDate: any = moment(EndDate).format("LT");
      formattedTime = `${startDate} - ${endDate}`;
    }

    return formattedTime;
  }

  public setAllDay(StartDate: string, EndDate: string): any {
    // let formattedTime: string = `All Day`;
    let setDates: any = {
      _startDate: StartDate,
      _endDate: EndDate,
    };
    console.log("before setEndDate >>", setDates._endDate);
    if (StartDate && EndDate && StartDate === EndDate) {
      setDates._endDate = moment(StartDate).add(24, "hours");
    }
    console.log("setEndDate >>", setDates);
    return setDates;
  }

  public openWindow(linkToEC: string): void {
    window.open(linkToEC, "_blank");
  }
  public addtoOutlook(ec: any): void {
    console.log("add this to outlook, generate ics", ec);
  }
  /* if the parent object passes down styles we need to use them */
  public setStylesFromParent(parentClasses: string): string {
    let returnStyles: string = styles.events;
    if (parentClasses) {
      if (parentClasses === "sitesAtoZcontainer") {
        returnStyles = `${styles.events} ${styles.sitesAtoZcontainer}`;
      }
      if (parentClasses === "companyNews") {
        returnStyles = `${styles.events} ${styles.companyNews}`;
      }
    }
    return returnStyles;
  }
  public createMockData(eventArray: EventDetails[], displayOptions: IDisplayOption[], displayCampaign: boolean): EventDetails[] {
    let calendarEvents: EventDetails[] = eventArray;
    calendarEvents = this.isTablet(displayOptions)
      ? calendarEvents.slice(0, 3)
      : displayCampaign
        ? calendarEvents.slice(0, 2)
        : calendarEvents.slice(0, 2);
    return calendarEvents;
  }

  public getNoResultsText(): string {
    return "Your saved filters currently do not have any upcoming events. Try changing your filters, save and then come back here.";
  }

  private async getCampaignBanner(): Promise<AdwCampaignBanner[]> {
    // private async getCampaignBanner(): Promise<any> {
    // private getCampaignBanner(): any {
    // let bannerPromise: Promise<AdwCampaignBanner[]>;
    const bannerArray: SpCampaignBanner[] = await this.spApiService.getListItemsWithAttachments<SpCampaignBanner>("Campaign Banner");
    const adwCampaignBanner: AdwCampaignBanner[] = bannerArray.map(SpCampaignBanner => {
      return new AdwCampaignBanner(SpCampaignBanner);
    });

    // console.log("bannerPromise >> ", bannerPromise);
    //  this.props.context.pageContext.web.absoluteUrl = "https://onyourside.sharepoint.com/sites/ADW-Dev";
    // const siteUrl: string = this.environmentService.getSiteUrl();
    // bannerPromise = this.spApiService.getListItems("Campaign Banner", siteUrl).then((spBanners: SpCampaignBanner[]) => {
    // this.spApiService.getListItems(this.props.context, "Campaign Banner", siteUrl).then((spBanners: any) => {
    //   const spCampaignBannerArray: SpCampaignBanner[] = spBanners;
    //   const adwCampaignBannerArray: AdwCampaignBanner[] = spCampaignBannerArray.map(spCampaignBanner => {
    //     return new AdwCampaignBanner(spCampaignBanner);
    //   });
    //   return adwCampaignBannerArray;
    //   //  console.log("spBanners >> ", spBanners);
    // });
    return adwCampaignBanner;
  }
  /***/
  public render(): React.ReactElement<IEventsProps> {
    return (
      <div className={this.state.eventClasses}>
        <div className={styles.toolsHeading}>
          <h4 className={styles.title}>Events</h4>
        </div>
        {this.showResultsPayDays(this.state.payDayArray)}
        <div className={styles.eventList}>{this.showResultsOrMessage(this.state.eventArray, this.state.linkToCalendar)}</div>
        <div className={styles.eventsBorder} />
        <div className={styles.visiteventlink}>
          <GoToLink linkText="View all events" url={this.state.linkToCalendar} target="new" id="linkToCalendar" />
        </div>
        {this.state.displayCampaign ? (
          <div className={styles.campaign}>
            <div className={styles.campaignWrapper}>
              <div className={styles.campaignImage}>
                <img src={this.state.campaignImage} width="392" height="200" />
              </div>
            </div>
          </div>
        ) : null}
      </div>
    );
  }
}

export default Events;
