import * as React from "react";
import styles from "./WeatherView.module.scss";
import { IWeatherProps } from "../../../webparts/weather/components/IWeatherProps";
import EnvironmentService from "../../../services/EnvironmentService";
import axios from "axios";
import { Button } from "react-bootstrap";
import Image from "../../atoms/Image/Image";
import Link from "../../atoms/Link/Link";
import { WeatherData } from "../../../types/WeatherTypes/WeatherData";
import { IInsideDataService } from "../../../interfaces/IInsideDataService";
import InsideDataService from "../../../services/InsideDataService";
import { InsideUserData } from "../../../types/InsideUserData";

export interface IWeatherViewState {
  Temperature: number;
  location: string;
  weathericon: string;
  onFocus: () => void;
  weatherContainer: string;
  Weather: string;
  searchBox: string;
  label: string;
  button: string;
  error: boolean;
  showSearch: boolean;
  errorCSSClassNames: string;
  zip: string;
  weatherCondition: WeatherData;
  logo: string;
  invalidZip: boolean;
  insideUserData: InsideUserData;
}

export interface IWeatherCondition {
  city: string;
  currentDescr: string;
  currentTemp: number;
  date: string;
  feelsLike: string;
  image: string;
  lastBuildDate: string;
  logoImg: string;
  state: string;
  time: string;
  timeZoneAbbreviation: string;
  warningIsActive: boolean;
  warningText: string;
  warningURL: string;
  zip: string;
}

class WeatherView extends React.Component<IWeatherProps, IWeatherViewState> {
  private _insideDataService: IInsideDataService;
  private Accuweather: string = require("../../../assets/images/Accurate.png");
  private logoErr: string = require("../../../assets/images/group-2-copy.png");
  private nwieID: string;
  constructor(props: IWeatherProps) {
    super(props);
    this.state = {
      Temperature: 0,
      location: "",
      weathericon: "",
      onFocus: () => false,
      weatherContainer: "",
      searchBox: "",
      Weather: "",
      label: "Change ZIP code",
      button: "",
      error: false,
      showSearch: false,
      errorCSSClassNames: "",
      zip: "",
      weatherCondition: undefined,
      logo: this.Accuweather,
      invalidZip: false,
      insideUserData: {} as InsideUserData,
    };
    this._insideDataService = new InsideDataService();
  }

  public onMouseEnterShow = (): void => {
    this.setState({ showSearch: true });
  };
  public onMouseLeaveHide = (): void => {
    this.setState({
      showSearch: false,
      label: "Change ZIP code",
      error: false,
      errorCSSClassNames: "",
      invalidZip: false,
      zip: "",
    });
  };

  public onImageMouseEnterShow = (e): void => {
    (e.target as HTMLInputElement).src = this.logoErr;
  };
  public onImageMouseLeaveShow = (e): void => {
    (e.target as HTMLInputElement).src = this.Accuweather;
  };
  public handleChange = (e): void => {
    this.setState({ zip: (e.target as HTMLInputElement).value });
    // console.log("handleChange >> ", (e.target as HTMLInputElement).value);
  };

  // public onFocusInput = (e): void => {
  //   console.log("onFocus >> ", (e.target as HTMLInputElement).value);
  // };

  // public onBlurInput = (e): void => {
  //   console.log("onBlurInput >> ", (e.target as HTMLInputElement).value);
  // };

  // public onKeyIpInput = (e): void => {
  //   console.log("onKeyIpInput >> ", (e.target as HTMLInputElement).value);
  // };
  public handleValidation = (zip: string): boolean => {
    let formIsValid: boolean = true;
    if (typeof zip !== undefined) {
      if (!zip.match(/^(?:\d{5})?$/)) {
        formIsValid = false;

        return formIsValid;
      }
    }
    return formIsValid;
  };

  private getWeather = (e): void => {
    e.preventDefault();
    const zip: string = this.state.zip;
    if (this.handleValidation(zip)) {
      this.setState({
        label: "Change ZIP code",
        error: false,
        errorCSSClassNames: "",
        invalidZip: false,
      });

      // const zip: string = this.state.zip;
      this.getWeatherDataByZipcode(zip);
    } else {
      this.setState({
        label: "Invalid ZIP code",
        error: true,
        errorCSSClassNames: "error",
        invalidZip: true,
      });
    }
  };

  private handleSaveWeatherClick = async (): Promise<void> => {
    const { insideUserData } = this.state;
    //get zip - this.getWeather()

    // insideUserData.getWeatherDataByZipcode= this.getWeather();
    await this._insideDataService.saveDataToInside(insideUserData);
    window.history.back();
    // get weather
    // get zip
    // set zip to insideUserData.weatherzip
    // insidue data sevice save data and pass in inside user
  };

  private getWeatherDataByZipcode = (zip: string): void => {
    this._insideDataService.getWeatherDataByZipcode(zip).then(data => {
      this.setState({ weatherCondition: data });
      const res: IWeatherCondition = this.state.weatherCondition.data;

      if (res.state !== null) {
        const temperature: number = res.currentTemp;
        const weatherIcon: string = this.getWeatherIcon(res.currentDescr);
        this.setState({
          Temperature: temperature,
          weathericon: weatherIcon,
          location: res.city + ", " + res.state,
          label: "Change ZIP code",
          error: false,
          errorCSSClassNames: "",
          invalidZip: false,
          showSearch: false,
          zip: "",
        });
        const { insideUserData } = this.state;
        console.log("insideUserData >", insideUserData);
        insideUserData.weatherZip = +zip;
        this._insideDataService.saveDataToInside(insideUserData).then(data => {
          console.log(data);
        });
        //  console.log("UID > ", this.nwieID, " Zip: ", +zip);
        // this._insideDataService.saveWeatherZipPreferences(this.nwieID, +zip).then(data => {
        //   // console.log(data);
        // });
      } else {
        this.setState({
          label: "Invalid ZIP code",
          error: true,
          errorCSSClassNames: "error",
          invalidZip: true,
        });
      }
    });
  };

  // public setLocalStorage = () => {
  //   localStorage.setItem("Temperature", JSON.stringify(this.state.Temperature));
  //   localStorage.setItem("location", JSON.stringify(this.state.location));
  //   localStorage.setItem("weathericon", JSON.stringify(this.state.weathericon));
  // };

  public getWeatherIcon = (currentDescr: string): string => {
    let weatherIcon: string = "";
    switch (currentDescr) {
      // 1
      case "Sunny":
      case "Mostly sunny":
      case "Partly sunny":
        weatherIcon = "sunny";
        break;

      // 2
      case "Intermittent clouds":
      case "Hazy sunshine":
      case "Mostly cloudy":
        weatherIcon = "partly-cloudy";
        break;

      // 3
      case "Cloudy":
      case "Dreary (overcast)":
      case "Fog":
        // case "Mostly cloudy":
        weatherIcon = "cloudy";
        break;

      // 4
      case "Light rain":
      case "Mostly cloudy w/ showers":
      case "Partly cloudy w/ showers":
      case "Partly sunny w/ showers":
      case "Rain":
      case "Showers":
        weatherIcon = "rainy";
        break;

      // 5
      case "T-storms":
      case "Mostly cloudy w/ t-storms":
      case "Partly cloudy w/ t-storms":
      case "Partly sunny w/ t-storms":
        weatherIcon = "thunderstorm";
        break;

      // 6
      case "Flurries":
      case "Mostly cloudy w/ flurries":
      case "Mostly cloudy w/ snow":
      case "Partly sunny w/ flurries":
      case "Snow":
        weatherIcon = "snow";
        break;

      // 7
      case "Windy":
        weatherIcon = "windy";
        break;

      // 8
      case "Clear":
      case "Hazy moonlight":
      case "Intermittent clouds":
      case "Mostly clear":
      case "Partly cloudy":
        weatherIcon = "night";
        break;

      // 9
      case "Freezing rain":
      case "Ice":
      case "Rain and snow":
      case "Sleet":
        weatherIcon = "mixed-percipitation";
        break;

      // 10
      case "Hot":
        weatherIcon = "hot";
        break;

      // 11
      case "Cold":
        weatherIcon = "cold";
        break;

      default:
        weatherIcon = "sunny";
    }
    return require(`../../../assets/images/${weatherIcon}-icon@2x.png`) as string;
  };

  public setLabel = (): void => {
    if (this.state.error) {
      const zip: string = "43215";
      this.getWeatherDataByZipcode(zip);
      this.setState({ label: "Invalid ZIP code" });

      // if (this.state.invalidZip) {
      //   this.setState({ logo: this.logoErr });
      // }
    } else {
      this.setState({ label: "Change ZIP code" });
      // if (!this.state.invalidZip) {
      //   this.setState({ logo: this.Accuweather });
      // }
    }
  };

  public componentDidMount(): void {
    this.nwieID = this.props.uID;
    this._insideDataService.getUserPreferences(this.nwieID).then(data => {
      // console.log("GET UID > ", this.nwieID, " Zip: ", data.weatherZip);
      let weatherZipValue: string = data && data.weatherZip ? data.weatherZip.toString() : "43215";
      this.getWeatherDataByZipcode(weatherZipValue);
      this.setState({
        insideUserData: data,
      });
    });
  }

  public render(): React.ReactElement<IWeatherProps> {
    return (
      <div className={this.props.weatherViewContainer} onMouseEnter={this.onMouseEnterShow} onMouseLeave={this.onMouseLeaveHide}>
        <div className={styles.WeatherInnerContainer}>
          <div className={this.state.showSearch ? styles.WeatherOutterContainer + " " + styles.opened : styles.WeatherOutterContainer}>
            {this.state.weathericon.length ? (
              <div className={styles.tempbox}>
                <div
                  className={styles.icon + " " + styles["icon-inline"] + " " + styles["icon-size"]}
                  style={{ backgroundImage: `url(${this.state.weathericon})` }}
                />

                <div className={styles.Temperature}>{this.state.Temperature} &deg;</div>
              </div>
            ) : (
              ""
            )}

            {this.state.showSearch ? (
              <div className={styles.WeatherContainer} onMouseEnter={this.onMouseEnterShow} onMouseLeave={this.onMouseLeaveHide}>
                <div className={styles.Weather}>{this.state.location}</div>
                <div className={this.state.invalidZip ? styles.label + " " + styles.error : styles.label}>{this.state.label}</div>

                <form>
                  <div className={styles.divcontainer}>
                    <input
                      className={this.state.invalidZip ? styles.searchBox + " " + styles.error : styles.searchBox}
                      value={this.state.zip}
                      placeholder="ZIP"
                      id="zip"
                      name="zip"
                      type="text"
                      pattern="^(?:\d{5})?$"
                      onChange={this.handleChange}
                      // onFocus={this.onFocusInput}
                      // onBlur={this.onBlurInput}
                      // onKeyUp={this.onKeyIpInput}
                    />
                    <Button
                      className={this.state.zip ? styles.savebutton + " " + styles.enabled : styles.savebutton + " " + styles.disabled}
                      onClick={this.getWeather}
                      disabled={!this.state.zip}
                    >
                      Save
                    </Button>
                    <div className={styles.Accurateimg}>
                      <Link url="https://www.accuweather.com/" target="new">
                        <Image
                          src={this.Accuweather}
                          onMouseOver={e => this.onImageMouseEnterShow(e)}
                          onMouseOut={e => this.onImageMouseLeaveShow(e)}
                          alt="Accuweather"
                        />
                      </Link>
                    </div>
                  </div>
                </form>
              </div>
            ) : null}
          </div>
        </div>
        {this.state.showSearch && <div className={styles.weatherBlueLine} />}
      </div>
    );
  }
}
export default WeatherView;
 